
# =============================================================================
# Group Name: 103-7
# Group Members:
#   1 - Ersin Cilek
#   2 - Elin Zandstra
#   3 - Jenna Hart
# =============================================================================



# =============================================================================
# IMPORT PACKAGES
# All imports go here, once. No repeated or unused imports anywhere below.
# Focus on the packages we have covered in the lab. Use other packages ...
# ... only when it is absolutely necessary. You will need to justify the use. 
# =============================================================================
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import scipy.stats as stats
import pingouin as pg
# imported seaborn for the normality histogram that shows the KDE 
import seaborn as sns

# fix the random generator so the jittered points are the same every run
np.random.seed(42)
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================
# DATASET 
# Dataset name / identifier: https://doi.org/10.1002/9781118628430.ch3
# Dataset 1 carries the full instructions and the rest follow the same pattern.
# =============================================================================
# =============================================================================
# =============================================================================
# =============================================================================


# -----------------------------------------------------------------------------
# 1.0 PRINT THE DATASET BANNER
# -----------------------------------------------------------------------------
text = "DATASET - Ruff et al. (2018) Osteological Data from Europe - DOI: https://doi.org/10.1002/9781118628430.ch3"
def banner(text, ch="=", length=109):
    print(ch * length)
    print(text.center(length))
    print(ch * length)
banner(text)

# -----------------------------------------------------------------------------
# 1.1 READ THE DATASET (Task 1)
# Read your analysis-ready CSV.
# -----------------------------------------------------------------------------
osteo = pd.read_csv("Ruff_Data_Clean.csv")

# Readable labels for the coded columns (SEX: 1 = male, 2 = female; RURAL/URBAN: 1 = rural, 2 = urban)
osteo["Sex"] = osteo["SEX"].map({1: "Male", 2: "Female"})
osteo["Setting"] = osteo["RURAL/URBAN"].map({1: "Rural", 2: "Urban"})

# -----------------------------------------------------------------------------
# 1.2 VISUALISATIONS (Task 2)
# Four visualisations for this dataset. Fonts, points and axis labels must be
# readable, and figures must not draw on top of one another.
# Each figure's title carries its number. Each caption is PRINTED to the
# console under its own label, around 40 words, describing what is shown rather
# than what it means.
# -----------------------------------------------------------------------------

# --- FIGURE 1 ---
# Print caption:
# Empty print function to get a blank space so the console reads clearer
print()

print("FIGURE 1")
print("Box plot comparing estimated anatomical stature (cm)"
      " between rural and urban individuals, separated by sex, in the Ruff"
      " et al. (2018) European osteoarchaeological dataset. Boxes represent"
      " interquartile ranges (IQR) and horizontal lines indicate medians. Whiskers"
      " extend to 1.5 x IQR, circles mark outliers and dots show individuals."
      " n = number of individuals with a stature estimate per group.")
# Code:

# Defining four groups    
urban_male = osteo[(osteo["RURAL/URBAN"] == 2) & (osteo["SEX"] == 1)]
urban_female = osteo[(osteo["RURAL/URBAN"] == 2) & (osteo["SEX"] == 2)]
rural_male = osteo[(osteo["RURAL/URBAN"] == 1) & (osteo["SEX"] == 1)]
rural_female = osteo[(osteo["RURAL/URBAN"] == 1) & (osteo["SEX"] == 2)]

# Pulling stature from each group
groups = [
    urban_male["STATURE"],
    rural_male["STATURE"],
    urban_female["STATURE"],
    rural_female["STATURE"]
    ]

# Create a boxplot
plt.boxplot(groups)

# Adding scattered individual points w/ jitter
plt.scatter(
    1 + np.random.normal(0, 0.04, len(urban_male)),
    urban_male["STATURE"],
    s=3,
    alpha=0.25
)

plt.scatter(
    2 + np.random.normal(0, 0.04, len(rural_male)),
    rural_male["STATURE"],
    s=3,
    alpha=0.25
)

plt.scatter(
    3 + np.random.normal(0, 0.04, len(urban_female)),
    urban_female["STATURE"],
    s=3,
    alpha=0.25
)

plt.scatter(
    4 + np.random.normal(0, 0.04, len(rural_female)),
    rural_female["STATURE"],
    s=3,
    alpha=0.25
)

stature_labels = [
    f"Urban Male\n(n = {len(urban_male)})", 
    f"Rural Male\n(n = {len(rural_male)})", 
    f"Urban Female\n(n = {len(urban_female)})",
    f"Rural Female\n(n = {len(rural_female)})"
    ]
                  

# Labelling boxes
plt.xticks(
    [1, 2, 3, 4],
    stature_labels
)
# Labelling y-axis
plt.ylabel("Stature (cm)")
# Title
plt.title("Figure 1: Stature by Urban/Rural Status & Sex")

# Show boxplot
plt.show()

# --- FIGURE 2 ---
# Print caption:
# Empty print function to get a blank space so the console reads clearer
print()

print("FIGURE 2")
print("Mean age at death across North and Central Europe from"
      " the Neolithic through Late Medieval periods in the Ruff et al. (2018)"
      " European osteoarchaeological dataset. The bars represent mean age at"
      " death for each chronological period. The number of individuals per"
      " period is shown under each bar.")
# Code:

# pull only North/Central Europe from data
north_central = osteo[osteo["REGION"] == "N.-Cen. Europe"]

# Calculate mean age of death by time period
mean_age = north_central.groupby("PERIOD")["AGE MEAN"].mean()

#Define Period Order
period_order = [
    "Neolithic",
    "Bronze",
    "Iron/Roman",
    "Early Medieval",
    "Late Medieval"
]

# put in chronological order
mean_age = mean_age.reindex(period_order)

# Number of individuals per period, for the labels (feedback from teacher: show n)
age_counts = north_central.groupby("PERIOD")["AGE MEAN"].count()
age_counts = age_counts.reindex(period_order)


# Tick labels: period name plus number of individuals (n) on a second line
period_labels = age_counts.index + "\n(n = " + age_counts.astype(str) + ")"


# Make plot
plt.bar(
    period_labels,
    mean_age.values
)

# Labelling x and y axis
plt.xlabel("Time Period")
plt.ylabel("Mean Age at Death (years)")

# Title
plt.title("Figure 2: Mean Age at Death Through Time in North-Central Europe")

# Rotating time period names so they are legible
plt.xticks(rotation=45)

# Show graph
plt.show()

# --- FIGURE 3 ---
# Print caption:
# Empty print function to get a blank space so the console reads clearer
print()

print("FIGURE 3")
print("Box plots showing maximum tibia length across five European regions"
      " in the Ruff et al. (2018) osteoarchaeological dataset, separated by"
      " sex. Boxes represent interquartile ranges (IQR) and horizontal lines indicate"
      " medians. Whiskers extend to 1.5 x IQR and circles mark outliers."
      " The number of males and females per region is shown under each pair of boxes.")

# Code:

# Defining regional groups by sex
balkans_male = osteo[(osteo["REGION"] == "Balkans") & (osteo["SEX"] == 1)]
balkans_female = osteo[(osteo["REGION"] == "Balkans") & (osteo["SEX"] == 2)]

britain_male = osteo[(osteo["REGION"] == "Britain") & (osteo["SEX"] == 1)]
britain_female = osteo[(osteo["REGION"] == "Britain") & (osteo["SEX"] == 2)]

iberia_male = osteo[(osteo["REGION"] == "Iberia") & (osteo["SEX"] == 1)]
iberia_female = osteo[(osteo["REGION"] == "Iberia") & (osteo["SEX"] == 2)]

ncenteuro_male = osteo[(osteo["REGION"] == "N.-Cen. Europe") & (osteo["SEX"] == 1)]
ncenteuro_female = osteo[(osteo["REGION"] == "N.-Cen. Europe") & (osteo["SEX"] == 2)]

scandfin_male = osteo[(osteo["REGION"] == "Scand./Finland") & (osteo["SEX"] == 1)]
scandfin_female = osteo[(osteo["REGION"] == "Scand./Finland") & (osteo["SEX"] == 2)]

# Pulling tibia length from each group
regiongroups = [
    balkans_male["TMAXLN"],
    balkans_female["TMAXLN"],
    
    britain_male["TMAXLN"],
    britain_female["TMAXLN"],
    
    iberia_male["TMAXLN"],
    iberia_female["TMAXLN"],
    
    ncenteuro_male["TMAXLN"],
    ncenteuro_female["TMAXLN"],
    
    scandfin_male["TMAXLN"],
    scandfin_female["TMAXLN"]
]

# Number of individuals per region and sex, for the labels (show "n")
tibia_counts = osteo.groupby(["REGION", "Sex"])["TMAXLN"].count().unstack()
region_labels = (
    tibia_counts.index 
    + "\n(M = " 
    + tibia_counts["Male"].astype(str) 
    + ", F = " 
    + tibia_counts["Female"].astype(str) 
    + ")"
    )
# Create a boxplot
boxplot = plt.boxplot(
    regiongroups,
    patch_artist=True
)

# X-ticks
plt.xticks(
    [1.5, 3.5, 5.5, 7.5, 9.5],
    region_labels
)
# rotating x-ticks for legibility
plt.xticks(rotation=45)
# Labelling y-axis
plt.ylabel("Max Tibia Length (mm)")
# Title
plt.title("Figure 3: Max Tibia Length by Region & Sex")

# Color male boxes blue
for box in boxplot["boxes"][::2]:
    box.set_facecolor("lightblue")

# Color female boxes pink
for box in boxplot["boxes"][1::2]:
    box.set_facecolor("pink")
    
# Legend
plt.plot([], [], color="lightblue", marker="s", label="Male")
plt.plot([], [], color="pink", marker="s", label="Female")

plt.legend(title="Sex", bbox_to_anchor=(1.05, 1), loc="upper left")


# Show boxplot
plt.show()

# --- FIGURE 4 ---
# Print caption:
# Empty print function to get a blank space so the console reads clearer
print()

print("FIGURE 4")
print("Outlined density histograms of absolute percentage "
      "asymmetry in humeral anteroposterior (AP; front-to-back) and "
      "mediolateral (ML; side-to-side) diameters at 50% shaft length, "
      "comparing urban and rural individuals in the Ruff et al. (2018) dataset. "
      "Both groups use identical 2% bins; the number of individuals per "
      "group is shown in the legend.")
# Code:

# LEFT HUMERUS
left_ap = osteo["HL50AP"]       # Left humerus AP diameter
left_ml = osteo["HL50ML"]       # Left humerus ML diameter

# RIGHT HUMERUS
right_ap = osteo["HR50AP"]      # Right humerus AP diameter
right_ml = osteo["HR50ML"]      # Right humerus ML diameter

# Calculate directional asymmetry
# Positive = right side larger
# Negative = left side larger
AP_difference = right_ap - left_ap
ML_difference = right_ml - left_ml

# Calculate absolute asymmetry
AP_absolute_asymmetry = np.abs(AP_difference)
ML_absolute_asymmetry = np.abs(ML_difference)

# Calculate percentage asymmetry
AP_percent_asymmetry = (
    AP_absolute_asymmetry /
    ((right_ap + left_ap) / 2)
) * 100

ML_percent_asymmetry = (
    ML_absolute_asymmetry /
    ((right_ml + left_ml) / 2)
) * 100

# Absolute percentage asymmetry as columns in osteo, for Table 1.4
osteo["AP_abs_asym"] = AP_percent_asymmetry
osteo["ML_abs_asym"] = ML_percent_asymmetry


# Directional AP asymmetry (%): positive = right side larger, negative = left side larger
osteo["AP_asym"] = (
    AP_difference /
    ((right_ap + left_ap) / 2)
) * 100

# Directional ML asymmetry (%): positive = right side larger, negative = left side larger
osteo["ML_asym"] = (
    ML_difference /
    ((right_ml + left_ml) / 2)
) * 100


# Separate Rural and Urban individuals
rural_ap = AP_percent_asymmetry[
    osteo["RURAL/URBAN"] == 1
]

urban_ap = AP_percent_asymmetry[
    osteo["RURAL/URBAN"] == 2
]

rural_ml = ML_percent_asymmetry[
    osteo["RURAL/URBAN"] == 1
]

urban_ml = ML_percent_asymmetry[
    osteo["RURAL/URBAN"] == 2
]

# Plot figure
plt.figure(figsize=(10, 4))

# Shared bin edges (2% wide), so rural and urban bars cover exactly the same ranges
ap_bins = np.arange(0, 42, 2)
ml_bins = np.arange(0, 32, 2)
# AP asymmetry subplot

plt.subplot(1, 2, 1)

plt.hist(
    rural_ap,
    histtype="step",
    linewidth=2,
    density= True,
    bins= ap_bins,
    label=f"Rural: n = {len(rural_ap)}"
)

plt.hist(
    urban_ap,
    histtype="step",
    linewidth=2,
    density= True,
    bins= ap_bins,
    label=f"Urban: n = {len(urban_ap)}"
)

plt.xlabel("AP Percent Asymmetry")
plt.ylabel("Density")
plt.title("Humeral AP Asymmetry")
plt.legend()

# ML asymmetry subplot


plt.subplot(1, 2, 2)

plt.hist(
    rural_ml,
    histtype="step",
    linewidth=2,
    density= True,
    bins= ml_bins,
    label=f"Rural: n = {len(rural_ml)}"
)

plt.hist(
    urban_ml,
    histtype="step",
    linewidth=2,
    density= True,
    bins= ml_bins,
    label=f"Urban: n = {len(urban_ml)}"
)

plt.xlabel("ML Percent Asymmetry")
plt.ylabel("Density")
plt.title("Humeral ML Asymmetry")
plt.legend()

# One numbered title for the whole figure, and spacing so nothing overlaps
plt.suptitle("Figure 4: Humeral AP and ML Asymmetry in Rural and Urban Individuals")
plt.tight_layout()

# Display plot
plt.show()

# -----------------------------------------------------------------------------
# 1.3 DESCRIPTIVE STATISTICS (Task 3)
# Print the caption first, then the statistics, in a clean readable layout.
# -----------------------------------------------------------------------------

# --- TABLE 1 ---
# Print caption:
# Empty print function to get a blank space between the tables so it reads easier
print()

print("TABLE 1")
print("Descriptive statistics of estimated stature (cm)"
      " for rural and urban individuals, split by sex, in the Ruff et al. (2018)"
      " dataset. Count = number of individuals (n), mean, std = standard deviation"
      ", min and max, and 25%, 50% (median) and 75% = the quartiles. These"
      " values go with the box plots in Figure 1.1.")
# Code:
stature_table = osteo.groupby(["Setting", "Sex"])["STATURE"].describe().round(2)
print(stature_table.to_string())

# ---TABLE 2 ---
# Print caption:
# Empty print function to get a blank space between the tables so it reads easier
print()

print("TABLE 2")
print("Descriptive statistics of age at death (years) per period for"
      " North-Central Europe, in the Ruff et al. (2018) dataset."
      " Count = number of individuals (n), mean, std = standard deviation"
      ", min and max, and 25%, 50% (median) and 75% = the quartiles. These"
      " values go with the bar chart in Figure 1.2.")
# Code:
age_table = north_central.groupby("PERIOD")["AGE MEAN"].describe().round(2).reindex(period_order)
print(age_table.to_string())

# ---TABLE 3 ---
# Print caption:
# Empty print function to get a blank space between the tables so it reads easier
print()

print("TABLE 3")
print("Descriptive statistics of the maximum tibia length (mm), by region and sex,"
      " in the Ruff et al. (2018) dataset. Count = number of individuals (n), mean,"
      " std = standard deviation, min and max, and 25%, 50% (median) and"
      " 75% = the quartiles. These values go with the box plots in Figure 1.3.")

# Code:
tibia_table = osteo.groupby(["REGION", "Sex"])["TMAXLN"].describe().round(2)
print(tibia_table.to_string())

# ---TABLE 4 ---
# Print caption:
# Empty print function to get a blank space between the tables so it reads easier
print()

print("TABLE 4")
print("Descriptive statistics of absolute percentage asymmetry (%) of the"
      " humeral AP and ML diameters at 50% shaft length, rural vs urban,"
      " in the Ruff et al. (2018) dataset. Count = number of individuals (n), mean,"
      " std = standard deviation, min and max, and 25%, 50% (median) and"
      " 75% = the quartiles. These values go with the histograms in Figure 1.4.")
# Code:
ap_table = osteo.groupby("Setting")["AP_abs_asym"].describe().round(2)
ml_table = osteo.groupby("Setting")["ML_abs_asym"].describe().round(2)

# Empty print function to get a blank space between the tables so it reads easier
print()

print("AP asymmetry (%)")
print(ap_table.to_string())

# Empty print function to get a blank space between the tables so it reads easier
print()

print("ML asymmetry (%)")
print(ml_table.to_string())

# --- Confidence Intervals ---

# CI's for Stature: Sample size, sample SD and standard error of stature

stature_data = osteo["STATURE"].to_numpy()
stature_n = len(stature_data)
stature_mean = np.mean(stature_data)
stature_sd = np.std(stature_data, ddof=1)
std_err_stature = stature_sd / np.sqrt(stature_n)

# Critical t-values, the same for stature and AP_asym because both have n=712 (df=711)
t_90 = stats.t.ppf(0.95, stature_n - 1) # critical t-value for a two-sided 90% CI
t_95 = stats.t.ppf(0.975, stature_n - 1) # critical t-value for a two-sided 95% CI
t_99 = stats.t.ppf(0.995, stature_n - 1) # critical t-value for a two-sided 99% CI

# 0.90 CI
margin_90 = t_90 * std_err_stature # define margin of error for ranges
lower_stature_90 = stature_mean - margin_90 # lower limit of range
upper_stature_90 = stature_mean + margin_90 # upper limit of range

# 0.95 CI
margin_95 = t_95 * std_err_stature # define margin of error for ranges
lower_stature_95 = stature_mean - margin_95 # lower limit of range
upper_stature_95 = stature_mean + margin_95 # upper limit of range

# 0.99 CI
margin_99 = t_99 * std_err_stature # define margin of error for ranges
lower_stature_99 = stature_mean - margin_99 # lower limit of range
upper_stature_99 = stature_mean + margin_99 # upper limit of range


# CI's for AP_asym
apasym_data = osteo["AP_asym"].to_numpy()
apasym_n = len(apasym_data)
apasym_mean = np.mean(apasym_data)
apasym_sd = np.std(apasym_data, ddof=1)
std_err_apasym = apasym_sd / np.sqrt(apasym_n)

# 0.90 CI
margin_90 = t_90 * std_err_apasym # define margin of error for ranges
lower_apasym_90 = apasym_mean - margin_90 # lower limit of range
upper_apasym_90 = apasym_mean + margin_90 # upper limit of range

# 0.95 CI
margin_95 = t_95 * std_err_apasym # define margin of error for ranges
lower_apasym_95 = apasym_mean - margin_95 # lower limit of range
upper_apasym_95 = apasym_mean + margin_95 # upper limit of range

# 0.99 CI
margin_99 = t_99 * std_err_apasym # define margin of error for ranges
lower_apasym_99 = apasym_mean - margin_99 # lower limit of range
upper_apasym_99 = apasym_mean + margin_99 # upper limit of range

# --- TABLE 5 ---
# Table for the confidence intervals
ci_table = pd.DataFrame({
    "Variable": ["Stature (cm)", 
                 "Stature (cm)", 
                 "Stature (cm)", 
                 "AP asymmetry (%)", 
                 "AP asymmetry (%)", 
                 "AP asymmetry (%)"
                 ],
    "CI level": ["90%", "95%", "99%", "90%", "95%", "99%"],
    "Lower": [lower_stature_90,
              lower_stature_95, 
              lower_stature_99,
              lower_apasym_90,
              lower_apasym_95,
              lower_apasym_99],
    "Upper": [upper_stature_90, 
              upper_stature_95,
              upper_stature_99,
              upper_apasym_90,
              upper_apasym_95,
              upper_apasym_99]
    })


# Add a column to ci_table that shows the difference between the Upper and Lower CI values
ci_table["Width"] = ci_table["Upper"] - ci_table["Lower"]
ci_table = ci_table.round(2)
print()
print("TABLE 5")
print("Confidence intervals (90%, 95% and 99%) of the mean estimated stature (cm)"
      " and directional AP humeral asymmetry (%) for all individuals in the"
      " Ruff et al. (2018) dataset (n = 712), calculated with the"
      " t-distribution (df = n - 1). Lower and Upper are the interval limits;"
      " Width is Upper minus Lower.")
print(ci_table.to_string(index=False))

# --------------------------------------------------
# 1.5 HYPOTHESIS TEST
# One-sample and two-sample t-tests, chi-square test
# --------------------------------------------------

# --- Normality check AP asymmetry ---
# --- FIGURE 5 ---
print()
print("FIGURE 5")
print("Histogram of directional anteroposterior (AP) humeral asymmetry (%) at"
      " 50% shaft length for all individuals in the Ruff et al. (2018) dataset"
      " (n = 712). The bars show the number of individuals per bin. The line is"
      " a kernel density estimate (KDE). Positive values mean the right side is"
      " larger.")
# Histogram with kernel density estimate to show the trend of the data
sns.histplot(
    data=osteo["AP_asym"],
    kde=True
    )

plt.title("Figure 5: Distribution of Directional AP Asymmetry")
plt.xlabel("Directional AP asymmetry (%)")
plt.ylabel("Count")
plt.show()

# --- FIGURE 6 ---
print()
print("FIGURE 6")
print("Q–Q plot of directional AP humeral asymmetry (%) in the Ruff et al."
      " (2018) dataset (n = 712). Every dot is an individual, the x-axis shows"
      " the expected values with a normal distribution, and the red line is"
      " where the dots would be located if the data was normally distributed.")

# Q-Q plot
stats.probplot(osteo["AP_asym"], plot=plt)

plt.title("Figure 6: Q–Q Plot of Directional AP Asymmetry")
plt.show()

# --- TABLE 6 ---
print()
print("TABLE 6")
print("Normality and one-sample tests for directional AP humeral asymmetry (%)"
      " in the Ruff et al. (2018) dataset (n = 712): Shapiro–Wilk normality"
      " test, one-sample t-test against 0, and Wilcoxon signed-rank test"
      " against 0. Tests are two-sided at α = 0.05 and 0.01.")

# H0: there is a normal distribution for the AP asymmetry
# H1: there is no normal distribution for the AP asymmetry
ap_normality = pg.normality(osteo["AP_asym"])
print()
print("Shapiro-Wilk:")
print(ap_normality.to_string())
# p < 0.05 and < 0.01, so we reject H0
# Histogram and Q–Q plot: the middle follows a normal distribution, only the
# tails deviate (mostly the right tail, a few individuals at 29-40%).
# Shapiro-Wilk is very sensitive with a large sample (n = 712), so it flags
# even small deviations. We trust the plots more: the deviation is small.
# The t-test is kept (course guideline: continue and report),
# the Wilcoxon test is added as a non-parametric check.


# H0: the mean directional AP asymmetry is 0 (no side bias)
# H1: the mean directional AP asymmetry is not 0
ap_ttest = pg.ttest(osteo["AP_asym"], 0)
print()
print("One-sample t-test:")
print(ap_ttest.to_string())
# Decision: p < 0.05 and p < 0.01, so we reject H0 at both levels.
# The mean AP asymmetry is positive: the right humerus is larger on average.

# Wilcoxon signed-rank test (non-parametric check)
# H0: the median directional AP asymmetry is 0 (no side bias)
# H1: the median directional AP asymmetry is not 0
ap_wilcoxon = pg.wilcoxon(x=osteo["AP_asym"])
print()
print("Wilcoxon signed-rank test:")
print(ap_wilcoxon.to_string())
# Wilcoxon: p < 0.05 and < 0.01, so we reject H0 at both levels.
# Same decision as the t-test: the conclusion does not change.

# --- Normality check ML asymmetry ---
# --- FIGURE 7 ---
print()
print("FIGURE 7")
print("Histogram of directional mediolateral (ML) humeral asymmetry (%) at"
      " 50% shaft length for all individuals in the Ruff et al. (2018) dataset"
      " (n = 712). The bars show the number of individuals per bin. The line is"
      " a kernel density estimate (KDE). Positive values mean the right side is"
      " larger.")
# Histogram with kernel density estimate to show the trend of the data
sns.histplot(
    data=osteo["ML_asym"],
    kde=True
    )

plt.title("Figure 7: Distribution of Directional ML Asymmetry")
plt.xlabel("Directional ML asymmetry (%)")
plt.ylabel("Count")
plt.show()

# --- FIGURE 8 ---
print()
print("FIGURE 8")
print("Q–Q plot of directional ML humeral asymmetry (%) in the Ruff et al."
      " (2018) dataset (n = 712). Every dot is an individual, the x-axis shows"
      " the expected values with a normal distribution, and the red line is"
      " where the dots would be located if the data was normally distributed.")

# Q-Q plot
stats.probplot(osteo["ML_asym"], plot=plt)

plt.title("Figure 8: Q–Q Plot of Directional ML Asymmetry")
plt.show()

# --- TABLE 7 ---
print()
print("TABLE 7")
print("Normality and one-sample tests for directional ML humeral asymmetry (%)"
      " in the Ruff et al. (2018) dataset (n = 712): Shapiro–Wilk normality"
      " test, one-sample t-test against 0, and Wilcoxon signed-rank test"
      " against 0. Tests are two-sided at α = 0.05 and 0.01.")

# H0: there is a normal distribution for the ML asymmetry
# H1: there is no normal distribution for the ML asymmetry
ml_normality = pg.normality(osteo["ML_asym"])
print()
print("Shapiro-Wilk:")
print(ml_normality)
# p < 0.05 and < 0.01, so we reject H0
# Conclusion: The plots show an almost normal distribution for the ML asymmetry.
# The deviation is only because of some extreme individuals.


# H0: the mean directional ML asymmetry is 0 (no side bias)
# H1: the mean directional ML asymmetry is not 0
ml_ttest = pg.ttest(osteo["ML_asym"], 0)
print()
print("One-sample t-test:")
print(ml_ttest.to_string())
# p < 0.05 and < 0.01, so we reject H0 at both levels.

# Wilcoxon signed-rank test (non-parametric check)
# H0: the median directional ML asymmetry is 0 (no side bias)
# H1: the median directional ML asymmetry is not 0
ml_wilcoxon = pg.wilcoxon(x=osteo["ML_asym"])
print()
print("Wilcoxon signed-rank test:")
print(ml_wilcoxon.to_string())
# Wilcoxon: p < 0.05 and < 0.01, so we reject H0 at both levels.
# Same decision as the t-test: the conclusion does not change.


# Two sample t-test
rural_woman_stature = rural_female["STATURE"]
urban_woman_stature = urban_female["STATURE"]

# --- Normality check rural women stature ---
# --- FIGURE 9 ---
print()
print("FIGURE 9")
print("Histogram of the estimated stature (cm) of rural women in the Ruff et"
      " al. (2018) dataset (n = 185). The bars show the number of individuals"
      " per bin. The line is a kernel density estimate (KDE).")
# Histogram with kernel density estimate to show the trend of the data
sns.histplot(
    data=rural_woman_stature,
    kde=True
    )

plt.title("Figure 9: Distribution of Stature, Rural Women")
plt.xlabel("Stature (cm)")
plt.ylabel("Count")
plt.show()

# --- FIGURE 10 ---
print()
print("FIGURE 10")
print("Q–Q plot of the estimated stature (cm) of rural women in the Ruff et"
      " al. (2018) dataset (n = 185). Every dot is an individual, the x-axis shows"
      " the expected values with a normal distribution, and the red line is"
      " where the dots would be located if the data was normally distributed.")

# Q-Q plot
stats.probplot(rural_woman_stature, plot=plt)

plt.title("Figure 10: Q–Q Plot of Stature, Rural Women")
plt.show()

# --- Normality check urban women stature ---
# --- FIGURE 11 ---
print()
print("FIGURE 11")
print("Histogram of the estimated stature (cm) of urban women in the Ruff et"
      " al. (2018) dataset (n = 120). The bars show the number of individuals"
      " per bin. The line is a kernel density estimate (KDE).")

# Histogram with kernel density estimate to show the trend of the data
sns.histplot(
    data=urban_woman_stature,
    kde=True
    )

plt.title("Figure 11: Distribution of Stature, Urban Women")
plt.xlabel("Stature (cm)")
plt.ylabel("Count")
plt.show()

# --- FIGURE 12 ---
print()
print("FIGURE 12")
print("Q–Q plot of the estimated stature (cm) of urban women in the Ruff et"
      " al. (2018) dataset (n = 120). Every dot is an individual, the x-axis shows"
      " the expected values with a normal distribution, and the red line is"
      " where the dots would be located if the data was normally distributed.")

# Q-Q plot
stats.probplot(urban_woman_stature, plot=plt)

plt.title("Figure 12: Q–Q Plot of Stature, Urban Women")
plt.show()

# --- TABLE 8 ---
print()
print("TABLE 8")
print("Normality and two-sample tests for the estimated stature (cm) of rural"
      " and urban women in the Ruff et al. (2018) dataset (rural n = 185,"
      " urban n = 120): Shapiro–Wilk normality test per group, variance ratio,"
      " and two-sample t-test comparing rural and urban women. Tests are"
      " two-sided at α = 0.05 and 0.01.")

# H0: there is a normal distribution for the stature of rural and urban women
# H1: there is no normal distribution for the stature of rural and urban women
rural_women_normality = pg.normality(rural_woman_stature)
urban_women_normality = pg.normality(urban_woman_stature)
print()
print("Shapiro-Wilk, Rural women:")
print(rural_women_normality)
print()
print("Shapiro-Wilk, Urban women:")
print(urban_women_normality)
# p > 0.05 and > 0.01 for both groups, so we fail to reject H0: normal.
# Histograms and Q–Q plots agree: symmetric and close to the line.
# All three checks agree, so the two-sample t-test is appropriate and
# the Mann-Whitney U test is not needed.

variance_ratio = np.var(rural_woman_stature) / np.var(urban_woman_stature)
print()
print(f"Variance ratio: {variance_ratio:.2f}")
# Ratio < 4, so the variances are similar enough for the two-sample t-test

# H0: rural and urban women have the same mean stature (μ_rural = μ_urban)
# H1: the mean stature of rural and urban women differs (μ_rural != μ_urban)
stature_ttest = pg.ttest(rural_woman_stature, urban_woman_stature, correction=False)
print()
print("Two-sample t-test:")
print(stature_ttest.to_string())
# Decision: p < 0.05 and < 0.01, so we reject H0 at both levels.

# --- TABLE 9 ---
print()
print("TABLE 9")
print("Chi-square test of independence between Sex and Setting in the Ruff"
      " et al. (2018) dataset (n = 712): observed counts, percentage of each"
      " sex per setting, test result (chi2, p, dof) and expected frequencies."
      " Decided at α = 0.05 and 0.01, without Yates' correction.")
# Chi square test
sex_setting_table = pd.crosstab(osteo["Sex"], osteo["Setting"])
print()
print("Observed counts (Sex x Setting):")
print(sex_setting_table)

sex_setting_percentage = (pd.crosstab(osteo["Sex"], osteo["Setting"], normalize="columns")* 100).round(1)
print()
print("Percentage of each setting (%):")
print(sex_setting_percentage)
# calculating chi2, p, dof, and expected values
chi2_sex, p_sex, dof_sex, expected_sex = stats.chi2_contingency(sex_setting_table, correction=False)
print()
print(f"The chi2 is: {chi2_sex:.2f}")
print(f"The p is: {p_sex:.3f}")
print(f"The dof is: {dof_sex}")
print()
print("Expected frequencies:")
print(expected_sex.round(2))
# p = 0.542 > 0.05 and > 0.01, so we fail to reject H0 at both levels.
# No evidence of an association between sex and setting: the proportion of
# women is similar in the rural (42%) and urban (44%) samples
# So comparisons that use both sexes (Fig 1.4, Table 1.4) are not distorted by sex.


# --- TABLE 10 ---
print()
print("TABLE 10")
print("Pearson and Spearman correlation between directional AP and ML humeral"
      " asymmetry (%) in the Ruff et al. (2018) dataset (n = 712). Tests are"
      " two-sided at α = 0.05 and 0.01.")

# --- Correlation: AP vs ML asymmetry ---
# H0: no correlation between directional AP and ML asymmetry
# H1: there is a correlation

asym_corr = pg.corr(osteo["AP_asym"], osteo["ML_asym"])

print()
print(asym_corr.to_string())
# p = 0.474 > 0.05 and > 0.01, so we fail to reject H0: no significant correlation
# r = -0.03 is practically zero
# AP and ML asymmetry vary independently: a right-side bias in one direction
# does not predict a bias in the other.

# Spearman rank correlation (non-parametric check)
# H0: no correlation between directional AP and ML asymmetry
# H1: there is a correlation
asym_spearman = pg.corr(osteo["AP_asym"], osteo["ML_asym"], method="spearman")
print()
print(asym_spearman.to_string())
# Spearman: p = 0.691 > 0.05 and > 0.01, so we fail to reject H0.
# r = 0.01 is practically zero, the same conclusion as Pearson:
# the conclusion does not change.
